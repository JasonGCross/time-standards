CREATE TABLE Stroke
(
       Name CHAR(10) NOT NULL PRIMARY KEY
     , Description VARCHAR(32) NULL
);
GO

